Cara Menggunakan

Ekstrak ZIP
1. Ekstrak file ZIP ke lokasi yang diinginkan.
2. Jalankan Build_Projek_Folder.bat
3. Klik dua kali pada Build_Projek_Folder.bat.
4. Masukkan Nama Proyek
5. Saat diminta, ketik nama proyek lalu tekan Enter.
Proses Pembuatan Folder dan Dummy
Script akan secara otomatis membuat struktur folder proyek.
File dummy akan dipindahkan dan di-generate sesuai format yang diperlukan.
6. Akses Proyek
7. Setelah proses selesai, buka folder proyek yang telah dibuat.
8. File dummy sudah tersedia dan siap digunakan.
9. Gunakan Shortcut (Opsional)
Shortcut ke folder proyek dan file dummy tersedia di D:\00-Projek Shortcut untuk akses cepat.

Catatan

1. Jangan memodifikasi atau menghapus folder DummyHidden agar proses berjalan dengan lancar.
2. Jika terjadi kesalahan, pastikan file dummy tersedia sebelum menjalankan Build_Projek_Folder.bat.

Selamat bekerja! 🚀